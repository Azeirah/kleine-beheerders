/* This file was automatically generated.  Do not edit! */
void delay(int noops);
void incrementLeds(char direction,char *currentLed);
void toggleRGB(char rgb);
unsigned char readButtons();
void initButtons();
void initLeds();
int main(void);
