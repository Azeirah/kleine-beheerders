/* This file was automatically generated.  Do not edit! */
unsigned char readButtons();
void initButtons();
