/* This file was automatically generated.  Do not edit! */
#if defined (__CODE_RED)
extern __CRP const unsigned int CRP_WORD;
#endif
