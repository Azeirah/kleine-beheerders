/* This file was automatically generated.  Do not edit! */
void shineOnMe();
void delay(int noops);
void kitt();
void toggleLeds(char leds,char direction);
void incrementLeds(char direction,char *currentLed);
void toggleRGB(char rgb);
void ledsWriteRGB(unsigned char rgb);
void setLeds(unsigned char ledMask);
void initLeds();
