/* This file was automatically generated.  Do not edit! */
void delay(int noops);
